import java.util.*;
import java.sql.*;
import java.io.*;

// James Jackson & Johnnie Oldfield
public class JDBC {
    public static void main (String args []) throws SQLException, ClassNotFoundException, IOException {
    	System.out.println();
	    //Load MySql JDBC Driver
	    try {
	    	Class.forName("com.mysql.cj.jdbc.Driver");
	    } catch (Exception e) {
	        System.out.println ("Could not load the driver");
		}
	    
	    // Get user input.  User name is assumed root
	    String usrname = "root";
	    System.out.println("Username is " + usrname + ".");
	    Scanner input = new Scanner(System.in);
	    System.out.println("Enter password: ");
	    String pswd = input.next();
	    input.close();
	    
	    // Get connection to database
	    Connection myconn = DriverManager.getConnection("jdbc:mysql://localhost:3306/nba_JamesJackson_JohnnieOldfield?useSSL=false&useUnicode=true&serverTimezone=UTC", usrname, pswd);
	    System.out.println("DB connected..\n");
	    
	    Statement mystmt = myconn.createStatement();
	    
	    // query1
	    System.out.println("Query 1 (Find tallest player): ");
	    String query1 = "select fName, lName, h_feet, h_inches from players where (h_feet * 12) + h_inches = (select max((h_feet * 12) + h_inches) from players)";
	    ResultSet r1 = mystmt.executeQuery(query1);
	    while (r1.next ()) {
	      String fName = r1.getString(1);
	      String lName = r1.getString(2);
	      String h_feet = r1.getString(3);
	      String h_inches = r1.getString(4);
	
	      // Display results
	      System.out.println("The tallest palyer is (" + fName + " " + lName +") who is (" + h_feet + ") feet and (" + h_inches + ") inches tall.\n");
	    }
	    
	    // query2
	    System.out.println("Query 2 (Find coach with largest number of season wins in the career): ");
	    String query2 = "SELECT fName, lName, max(seasonWin) FROM coaches_career";
	    ResultSet r2 = mystmt.executeQuery(query2);
	    while (r2.next ()) {
	      // Set variables
	      String fName = r2.getString(1);
	      String lName = r2.getString(2);
	      String seasonWin = r2.getString(3);
	
	      // Display results
	      System.out.println("The coach with the highest number of season wins in career is (" + fName + " " + lName +") with (" + seasonWin + ") wins.\n");
	    }
	    
	    // query3
	    System.out.println("Query 3 (List all teams from San Diego): ");
	    System.out.println("Here is a list of all teams from San Diego.");
	    String query3 = "SELECT team_name FROM teams WHERE location = 'San Diego'";
	    ResultSet r3 = mystmt.executeQuery(query3);
	    while (r3.next ()) {
	      // Set variables
	      String team_name = r3.getString(1);

	
	      // Display results
	      System.out.println("   *" + team_name);
	    }
	
	    //Close objects
	    mystmt.close();
	    myconn.close();
	}
}

