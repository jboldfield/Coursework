# James Jackson & Johnnie Oldfield

#Query 1
#select fName, lName, h_feet, h_inches from players where (h_feet * 12) + h_inches = (select max((h_feet * 12) + h_inches) from players);

#Query 2
#SELECT fName, lName, max(seasonWin) FROM coaches_career

#Query 3
#select team_name, location from teams where location = "San Diego";
