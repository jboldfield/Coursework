module Admin
  class SuperAccountsController < Admin::ApplicationController
  end
end