import "catalog"; // This imnplies to use app/javascript/catalog/index.js
