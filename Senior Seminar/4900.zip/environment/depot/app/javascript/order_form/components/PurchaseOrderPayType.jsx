import React from 'react'

export default class PurchaseOrderPayType extends React.Component {
  render() {
    return (
      <div>
        <div className="field">
          <label htmlFor="order_po_number">PO #</label>
          <input type="password"
                 name="order[po_number]" 
                 id="order_po_number"
                 className="form-control form-control-lg" />
        </div>
      </div>
    );
  }
}