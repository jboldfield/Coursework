/* Source Author: Robert I. Pitts <rip@cs.bu.edu>
(Code has been modified for demonstration purpose) */

/* Demonstrates how data can be read from, and written to 
files. Closing of files after processing is important. */

#include <stdio.h>
#include <stdlib.h>

int main(void)
{
  FILE *ifp, *ofp, *ifp2; // file pointers (handler)
  char *mode = "r"; // optional: you can put the mode directly when openning the file, however, this gives flexibility
  char outputFilename[] = "letter.txt"; // you can choose other file name
  char username[9];  /* One extra for nul char. */
  int score, count, sum = 0, average = 0;

  ifp = fopen("grades.txt", mode);

  if (ifp == NULL) {
    fprintf(stderr, "Can't open input file!\n"); // Note the use of stderr; this may help in creating a log of all errors
    exit(1); //optional
  }

  ofp = fopen(outputFilename, "w");

  if (ofp == NULL) {
    fprintf(stderr, "Can't open output file %s!\n", outputFilename);
    
  }

  while (fscanf(ifp, "%s %d", username, &score) == 2) {
    char grade;
	score += 2;
	//Get letter grade
	if (score >= 90)
  		grade = 'A';
	else if (score >= 80)
  		grade = 'B';
	else if (score >= 70)
  		grade = 'C';
	else if (score >= 60)
  		grade = 'D';
	else
  		grade = 'F';

  	//Sum and count for average
  	sum += score;
  	count++;
  	
  	//Print to file
  	fprintf(ofp, "%s %d %c\n", username, score, grade); // simple processing just bumping the grades by 2 points
  }
  average = sum / count;
  ifp2 = fopen("grades.txt", mode);
  int intArr[count];
  count = 0;
  while (fscanf(ifp2, "%d", &score) == 1) {
  	printf("%d ", score);
  	intArr[count] = score;
  	count++;
  }
  
  int max = intArr[0], min = intArr[0];
  int size;
  size = sizeof(intArr)/sizeof(intArr[0]);

  for(int i = 0; i < size; i++){
  	//Fin highest grade
  	if (intArr[i] > max)
  		max = intArr[i];
  	//Find lowest grade
  	if (intArr[i] < min)
  		min = intArr[i];
  }
  puts("");
  //Print highest, lowest, and average
  fprintf(ofp, "\nThe highest grade is %d", max);
  fprintf(ofp, "\nThe lowest grade is %d", min);
  fprintf(ofp, "\nThe grade average is %d", average);
  
  fclose(ifp); // closing of input file
  fclose(ifp2);// closing of inout file
  fclose(ofp); // closing of output file
  
  //fclose returns 0 if file is successfully closed, otherwise returns EOF, commonly -1

  return 0;
}