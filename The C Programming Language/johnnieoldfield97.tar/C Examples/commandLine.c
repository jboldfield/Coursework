/*	Write code that can add some numbers(integers) supplied
 * 	as command line argumentds, and display the sum.
 *	Function atoi() converts string into int
 *	Test case: ./a.out 3 11 5 = 20
 */

#include <stdio.h>
int main (int argC, char *argV[]){
	
}