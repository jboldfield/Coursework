#include <stdio.h>

void main(){
	int x, rev, rem; 
	puts("Enter a number no more than 6 digits  (Ex.  345):");
	scanf("%6d", &x);
	
	while (x != 0){
		rem = x % 10;
		rev = rev * 10 + rem;
		x /= 10;
	}
	printf("Reversed number: %d", rev);
	puts("");
}