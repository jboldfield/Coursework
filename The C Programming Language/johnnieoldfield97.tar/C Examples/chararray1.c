/* Example demonstrating character array (string) buffer overflow.
fgets() can mitigate this issue. However, it works only for strings, 
and only one string (one buffer) at a time. */
 
#include<stdio.h>

int main(){

   char food[5];
   puts("Enter food: ");
   /*
   scanf("%s", food);
   printf("%d\n", sizeof(food));
   printf("Food is: %s\n", food); // try entering a food item with more than 5 characters
   */
   
   //comment out lines 7, 8, 9 and uncomment the following and check the output
   
   fgets(food, sizeof(food)+1, stdin); /* stops the buffer overflow */
   printf("%d\n", sizeof(food));
   printf("Food is: %s\n", food);
   
   return 0;
}
