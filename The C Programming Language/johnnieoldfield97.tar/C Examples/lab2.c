/* Program finds "smallest" to "largest" in a series of words. The user will enter 
a set of words, one at a time after a prompt. The user enters the special word "zyzy" 
to indicate end of input. The program displayes smallest and largest in dictionary 
order. You can assume that no word is more than 10 letters long. */

#include <stdio.h>
#include <string.h>

void main(){
	char dic[10][10];
	char word[10], temp[10];
	scanf("%s", word);
	//copy to temp
	strcpy(temp, word);
	while(strcmp(word, "zyzy") != 0){
		if(strcmp(word, temp) < 0){
			//copy word to temp
			strcpy(temp, word);
		}
		//scanf()
	}
}