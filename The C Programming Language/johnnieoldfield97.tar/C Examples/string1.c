/* Program finds "smallest" to "largest" in a series of words. The user will enter 
a set of words, one at a time after a prompt. The user enters the special word "zyzy" 
to indicate end of input. The program displayes smallest and largest in dictionary 
order. You can assume that no word is more than 10 letters long. */

#include <stdio.h>
#include <string.h>

void dictionarySort(char words[20][20], int *spots)
{
    int i, j;
    char temp[20];

    for (i = 0; i < *spots; ++i)
    {
        for (j = i + 1; j < *spots; ++j)
        {
            if (strcmp(words[i], words[j]) > 0)
            {
                strcpy(temp, words[i]);
                strcpy(words[i], words[j]);
                strcpy(words[j], temp);
            }
        }
    }

    printf("\n\nWords in dictionary order:\n");

    for (int i = 0; i < *spots - 1; i++)
    {
        printf("%s\n", words[i]);
    }
}

void findShortest(char words[20][20], int *spots)
{

    int shortest = strlen(words[0]);
    int shortestPos = 0;

    for (int i = 1; i < *spots - 1; i++)
    {
        int current = strlen(words[i]);
        if (shortest > current)
        {
            shortest = current;
            shortestPos = i;
        }
    }

    printf("\nThe smallest word was: %s", words[shortestPos]);
}

void findLongest(char words[20][20], int *spots)
{

    int longest = strlen(words[0]);
    int longestPos = 0;

    for (int i = 1; i < *spots - 1; i++)
    {
        int current = strlen(words[i]);
        if (longest < current)
        {
            longest = current;
            longestPos = i;
        }
    }

    printf("\nThe largest word was: %s", words[longestPos]);
}

int main()
{

    char words[20][20];
    int pos = 0;

    puts("Enter zyzy to end.");

    while (strcmp(words[pos - 1], "zyzy") != 0)
    {
        printf("Enter a word: ");
        scanf("%s", &words[pos]);
        pos++;
    }

    printf("\nWords:\n");

    for (int i = 0; i < pos - 1; i++)
    {
        printf("%s\n", words[i]);
    }

    findShortest(words, &pos);
    findLongest(words, &pos);

    dictionarySort(words, &pos);

    return 0;
}