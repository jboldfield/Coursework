#include <stdio.h>
void main(){
	#define X 38.0 //fahrenhiet
	float y;       //celsuis
	float far;     //fahrenhiet
	float cel;     //celsuis
	
	void tempCheck(float x){
		if (x > 90)
			puts("\tIt's hot!");
		else if (x < 49)
			puts("\tIt's cold!"); 
		else
			puts("\tThe weather is good!");
	}
	
	float farToCel(float x){
		float y = (x - 32) * 5/9;
		return y;
	}
	
	printf ("\tFahrenhiet is %.1f\n\t%s%.1f\n", X, "In celsius: ", farToCel(X));
	tempCheck(X);
	
	puts("\nEnter temperature in Fahrenhiet (Ex. 12.5):");
	scanf("%f", &far);
	
	printf ("\n\tFahrenhiet is %.1f\n\t%s%.1f\n", far, "In celsius: ", farToCel(far));
	tempCheck(far);
	puts("");
	
	for (int i = 0; i < 10; i++){
		printf("%d", i);
	}
	puts("");
	
	#define G 678
	printf("\nG is: %d\n", G);
	int F = G + 10;
	printf("F is: %d\n", F);
	
	//Example
	int y = 5;
	int *x = &y;
	
	printf("\n&x: %d", &x);
	printf("\n*x: %d", *x);
	printf("\nx: %d", x);
	printf("\n&y: %d", &y);
	//printf("\n*y: %d", *y);
	printf("\ny: %d", y);
	puts("");
}