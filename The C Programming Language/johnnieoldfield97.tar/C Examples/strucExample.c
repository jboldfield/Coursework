#include <stdio.h>
//Structure for coordiant point 
typedef struct{
	int x;
	int y;	
}point;


//try enum
int main(){
	point p;
 	
 	printf("Enter X and Y: (3 -5)");
 	scanf("%d %d", &p.x, &p.y);
 	
 	if (p.x < 0 && p.y > 0)
 		printf("Quadrant 1");
 	else if (p.x > 0 && p.y > 0)
 		printf("Quadrant 2");
 	else if (p.x > 0 && p.y < 0)
 		printf("Quadrant 3");
 	else 
 		printf("Quadrant 4");
 	printf("\n");
 	
 	//Accepts 6 points and displays all points in 1st quandrant
 	
 	return 0;
 }