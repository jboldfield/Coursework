#include<stdio.h>

int main(){
   int arr[5] = {56, 78, 98, 23, 47};
   
   int sum = 0;

   for (; *p; p++)
      //sum += *p;
      printf("%d ", *p);
   //printf("Sum of the numbers: %d\n", sum);
   
   return 0;
}
