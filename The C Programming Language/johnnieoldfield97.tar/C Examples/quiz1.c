#include<stdio.h>

void main (){
	int x = 10, y = 5;
	printf("%d %d %d", x++ - --y, x, y);
	
	x = 6, y = 7;
	int z = 8;
	printf("\n%d\n", x < y || ++y < z);
	printf("%d %d %d", x, y, z);
	
	char st[] = "Hi";
	char *pt = st;
	printf("\n%d", sizeof(st));
	
	char st2[] = "Hi";
	char *pt2 = st2;
	printf("\n%d", sizeof(pt2));
	
	char st3[] = "Hi";
	char *pt3 = st3;
	printf("\n%d", &st3 == st3);
	printf("\n%d", &pt3 == &st3);
	
	int a[5] = {1, 2, 3, 4, 5}; 
	--a[2];
	printf(a[2]);
	
}