#include <stdio.h>

int main(){
	/*int n;
	int numbs[n];
	puts("Enter n:");
	scanf("%d", &n);
	for (int i = 0; i < n; i++){
		printf("Enter %d-th number:\n", i);
		scanf("%d", &numbs[i]);
		printf("Number entered %d", numbs[i]);
	}*/
	puts("\n////////////////////////////////");
	int arr[] = {1, 2, 3};
	int *pt;
	pt = arr;
	printf("%d", *pt);
	printf("\n%d %d %d", pt, arr, &arr[0]);
	puts("\n////////////////////////////////");
	char ch = "abcd"[2];
	printf("%c", ch);
	puts("");
	return 0;
}