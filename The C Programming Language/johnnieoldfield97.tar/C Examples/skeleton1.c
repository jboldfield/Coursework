/* As some of you complained about the warning messages being
annoying, from now onwards we will write codes from bottom-up
approach. That is, we will write main() last. */

/* Complete the following skeleton code that finds highest and
   lowest numbers among a set of distinct numbers */

#include<stdio.h>

#define N 5

void Hi_lo(int arr[], int *hi, int *lo){
	//initialization
	*hi = arr[0];
	*lo = arr[0];
	int i;
	
  	/* comparison to determine the largest and the smallest */
	for(i = 0; i < N; i++){
		//High
		if(*hi > arr[i])
			*hi = arr[i];
		
		//Low
		else if(*lo < arr[i])
			*lo = arr[i];
	}
}

int main(){
  	int A[N] = {10, 7, 8, 4, 50}, i, high, low;
	
  	Hi_lo(A, &high, &low); /* why did we use 'address of' operator? */
  
  	printf("Highest = %d, and lowest = %d\n", high, low);
  	return 0;
}
