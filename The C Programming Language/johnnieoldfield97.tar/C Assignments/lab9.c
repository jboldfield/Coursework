#include<stdio.h>

void printarray(int *arrptr, int size){
  int i;
  for(i=0;i<size;i++){
    printf("%d\t", arrptr[i]);
  }
  printf("\n");
}


int main(){

  int a[5] = {1, 1, 1, 1, 1};
  int *p;
    
    /* 1. Indicate the output and explain (this one is done for you) */
    p = a;
    printarray(a, 5);
    printf("p = %p\t a = %p\n", p, a);
    /* Output: 1 1 1 1 1
    /* Explanation: It is same as the initial array, as 
    p is pointing to the first location of it. printing 
    of two addresses are same. */
    
   	/* 2. Indicate the output and explain */
    *p = 3;
    /* Output: 3 1 1 1 1 */
   	printarray(a, 5);
   	printf("p = %p\t a = %p\n", p, a);
    /* Explain: *p is initialized at 0 so it is pointing to a[0].
	*p is then set to 3 thus a[0] = 3. */    
    
    /* 3. Indicate the output and explain */
    *p++ = 5;
    /* Output: 5 1 1 1 1 */
   	printarray(a, 5);
    printf("p = %p\t a = %p\n", p, a);
    /* Explain: *p is still at a[0] and sets it equal to 5.
    Afterwards it increments the pointer and now it points
    to a[1]. */

    /* 4. Indicate the output and explain */
    *++p = 6;
    /* Output: 5 1 6 1 1 */
   	printarray(a, 5);
    printf("p = %p\t a = %p\n", p, a);
    /* Explain: The pointer is incrmented by 1 to point to a[2].
    Then it sets a[2] equal to 6*/

    
   /* 5. Indicate the output and explain */
    a[3] = (*p)++;
    /* Output: 5 1 7 6 1 */
   	printarray(a, 5);
    printf("p = %p\t a = %p\n", p, a);
    /* Explain: a[3] becomes whatever being pointed at (currently 
    pointing to a[6]). Thus a[3] = a[2] (6). (*p)++ then goes back
    to the pointer at a[2] then adds one.  a[2] = 7. */

   	/* 6. Indicate the output and explain */
    p = &a[4];
    *p = *(p - 2);
    /* Output: 5 1 7 6 7 */
   	printarray(a, 5);
    printf("p = %p\t a = %p\n", p, a);
    /* Explain: p points to variable at a[4]. *p is then set to 
    equal the position - 2.  So a[4] = a[2] (7)*/
    
    return 0;
}
