/*
 * 	Johnnie Oldfield
 * 	CS 3335
 * 	Fall 2018
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
	//Declare variables for input
	char input[31];
	int rot;
	//Get input
	puts("Enter statement (Strike at nine):");
	fgets(input, sizeof(input), stdin);
	puts("Enter roatation (2):");
	scanf("%1d", &rot);
	//Call encode
	encode(input, rot);
	return 0;
}
void encode(char input[31], int rot){
	//Initialize letter
	char letter;
	for(int i = 0; i < strlen(input) - 1; i++){
		//Set letter
    	letter = input[i];
    	//Change lowercase
    	if(letter >= 'a' && letter <= 'z'){
        	letter = letter + rot;
        	//To wrap alphabet
            if(letter > 'z')
                letter = letter - 'z' + 'a' - 1;
            input[i] = letter;
        }
        //Change uppercase
        else if(letter >= 'A' && letter <= 'Z'){
            letter = letter + rot;
            //To wrap alphabet 
            if(letter > 'Z')
                letter = letter - 'Z' + 'A' - 1;
            input[i] = letter;
        }
    }
    //Print message
	printf("%s", input);
}
