/*
 * 	Johnnie Oldfield
 * 	CS 3335
 * 	Fall 2018
 */

#include <stdio.h>

void main(){
	//Data field
	long number = 0;
	int i = 0, digit = 0;
	int counts[10] = {0};
	
	//Get input
	puts("Enter a number: ");
	scanf("%d", &number);
   
   	//Count digits
	while (number > 0) {
    	digit = number % 10; 
    	counts[digit]++;
    	number /= 10;
   	} 
   	
	//Print digits
	printf("Digit:\t");
	for (i = 0; i < 10; i++)
      printf("\t%d", i);
      
    //Print frequency  
	printf("\nFrequency:");
	for (i = 0; i < 10; i++)
    	printf("\t%d", counts[i]);
	puts("");
}
