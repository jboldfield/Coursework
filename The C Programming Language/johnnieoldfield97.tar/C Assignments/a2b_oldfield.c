/*
 * 	Johnnie Oldfield
 * 	CS 3335
 * 	Fall 2018
 */

#include <stdio.h>
void main(){
	int path;
	//Welcome screen
	puts("Enter what you want to do ('1' for integer to binary or '2' for binary to integer):");
    scanf("%1d", &path);
	
	//Path to convert decimal
    if(path == 1)
        DecimalToBinary();
        
    //Path to convert binary
    else if(path == 2)
        BinaryToDecimal();
}

void DecimalToBinary(){
	int decimal;
	//Get user input
	puts("Enter decimal number (Ex.  13):");
    scanf("%d", &decimal);
    printf("Decimal: %d", decimal);
    
    //Converter
    int base = 1, binary = 0, rem;
    while (decimal > 0){
    	rem = decimal % 2;
    	binary = binary + rem * base;
        decimal = decimal / 2;
        base = base * 10;
    }
    printf(" to Binary: %d", binary);
    puts("");
}

void BinaryToDecimal(){
	//Data 
	int binary;
	//Get user 
	puts("Enter binary number (Ex.  10011):");
    scanf("%d", &binary);
    printf("Binary: %d", binary);
    
    //Converter
    int rem, decimal = 0, base = 1;
    while (binary > 0){
    	rem = binary % 10;
        decimal = decimal + rem * base;
        binary = binary / 10 ;
        base = base * 2;
    }
    printf(" to Decimal: %d", decimal);
    puts("");
}
