#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define TRIALS 10

/*
 * Johnnie Oldfield
 * CS3335
 * Fall 2018
 */

void main(){
	//Data & random number
	int num, guess, count = 1;
	srand(time(NULL));
	num = rand() % 100 + 1;
	
	//Scan user input for guess
	puts("Welcome to the game!  Enter your guess (A number between 0 and 100), you have 10 tries: ");
	scanf("%d", &guess);
	
	//Decides if guess is too high, too low, or correct
	//While keeping track of attempts
	for (int i = 0; i < TRIALS; i++){
		//Ends after ten attempts, player loses
		if(count == 10){
			puts("You lose.");
			break;
		}
		////Ends after the guess if correct, player wins
		if(guess == num){
			printf("You won! The number was: %d", num);
			puts("");
			break;
		}
		//Player guessed too high, subtarct an attemot, player can guess again
		if(guess > num){
			puts("Incorrect!  Your guess was too high. \nEnter your guess (A number between 0 and 100): ");
			printf("Attempts left: %d", (TRIALS - count));
			puts("");
			scanf("%d", &guess);
		}
		//Player guessed too low, subtarct an attemot, player can guess again
		if(guess < num){
			puts("Incorrect!  Your guess was too low. \nEnter your guess (A number between 0 and 100): ");
			printf("Attempts left: %d", (TRIALS - count));
			puts("");
			scanf("%d", &guess);
		}
		count++;
	}
}