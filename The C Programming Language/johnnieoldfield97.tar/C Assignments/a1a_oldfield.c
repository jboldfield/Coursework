#include <stdio.h>
#define SIZE 5

/*
 * Johnnie Oldfield
 * CS3335
 * Fall 2018
 */

void main(){
	//Data field
	char letters[SIZE];
	int grades[SIZE];
	double sum = 0;
	float avg = 0;
	
	//User input for 5 grades
	for (int i = 0; i < SIZE; i++){
		puts("Enter grade (Ex. 90): ");
		scanf("%d", &grades[i]);
		
		//If-then-else
		if (grades[i] >= 90)
			letters[i] = 'A';
		else if (grades[i] >= 80)
			letters[i] = 'B';
		else if (grades[i] >= 70)
			letters[i] = 'C';
		else if (grades[i] >= 60)
			letters[i] = 'D';
		else 
			letters[i] = 'F';
	}
	
	//Output
	puts("Grades: ");
	for (int j = 0; j < SIZE; j++){
		sum += grades[j];
		printf("%d%c ", grades[j], letters[j]);
	}
	
	//Average
	avg = sum/SIZE;
	puts("");
	printf("Average: \n%.2f", avg);
	puts("");
}