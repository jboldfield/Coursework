/*
 * 	Johnnie Oldfield
 * 	CS 3335
 * 	Fall 2018
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]){
	//Set n
	int n = atoi(argv[1]);
	
	//Check if arguments are correct
	if (n < 1 || n > 15 || n % 2 == 0){
		puts("Invalid argument. (Use an odd integer 1-15)");
		return 0;
	}
	//If so run magic
	else
		magic(n);
		return 0;
}

void magic(int n){
	//Create magic box of size n
	//and set all elements to 0.
	int magicBox[n][n];
	memset(magicBox, 0, sizeof(magicBox[0][0]) * n * n);
	
	//Do magic
	//Set position to 1st row middle column
	int r = 0, c = n / 2;
	//Loop to set numbers
	for(int i = 1; i <= n * n;){
		//If position needs to warp around
		if(r < 0 && c == n){
			r += 2;
			c = n - 1;
		}
		else if (r < 0)
			r = n - 1;
		else if (c == n)
			c = 0;
		//If a number already exists in the position
		if (magicBox[r][c] > 0){
			r += 2;
			c--;
		}
		//Set number
		magicBox[r][c] = i++;
		
		//Increment row and decrement column
		//to determine next position.
		r--;
		c++;
	}
	
	//Print magic box and sum
	printf("Magic sum is %d\n", n * (n * n + 1) / 2);
	for(int i = 0; i < n; i++){
		for(int j = 0; j < n; j++)
			printf("%d\t", magicBox[i][j]);
		puts("\n");
	}
}