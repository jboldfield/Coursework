//***************************************************************************************
//Purpose: Receives data file from MyCounts6 and process the file 
//
//Input: Receive data file from MyCounts6  and add contents to an ArrayList
//Output: It prints the information after processing ends 				
//
//Author: Charles Samuel and Jonnie Oldfield
//Course: CS 1302
//Date:   2/16/2018
//Program: MyCounts6
//**************************************************************************************

import java.util.Scanner;
import java.io.File;
import java.util.ArrayList;

public class ProcessTokens6 {
 
 int nonEmptyLines;//Stores number of non-empty lines in data file  
 int allTokens;//Stores number of tokens in data file
 int alphabetTokens;//Stores number of alphabet tokens in data file
 int integerTokens;//Stores number of integer tokens in data file
 int doubleTokens;//Stores number of double tokens in data file
 int otherTokens;//Stores number of Special tokens in data file
 
 int totalCountOfTokens;//Stores total amount of tokens
 int numOfCharacters;//Stores number of character tokens in data file
 int numOfDigits;//Stores number of digit tokens in data file
 int numOfLetters;//Stores number of letter tokens in data file
 int numOfSpecialCharacters;//Stores number of Special tokens in data file
 
 int index;
 String index2;
 double max = 0;
 
 ArrayList<String> list = new ArrayList<String>();//Stores contents of data file
 
 //Adds data file content to arraylist 
 public void addFiletoArrayList(Scanner scan){
     while(scan.hasNext()){
      list.add(scan.next());
     }
     scan.close();
  }//end of method
 
 //Prints the contents of file and seperates by tab   
	public void printAllTokens() {
      System.out.println("1.  All Tokens");
      System.out.println();
      
      //loops through arraylist and prints contents
      for(int j = 0; j < list.size(); j++){
       System.out.println((j + 1) + "\t" + list.get(j));
       
       //increment by one
       allTokens++;
      }
      
      System.out.println();
   }//end of method
	
  //Prints tokens that contain letters 
   public void printAllAlphabetTokens(){
      int i = 1;//numeric lable
      String regex = "[A-Za-z]+";//used to look for String pattern
      
      System.out.println("2.  All Alphabet Tokens");
      System.out.println();

     //loops through arraylist
      for(int j = 0; j < list.size(); j++){
       String a = list.get(j);
       
       //checks if string contains letter
       if(a.matches(regex)){
        
        //prints contents
        System.out.println(i + "\t" + list.get(j));
        
        //increment by one
        alphabetTokens++;
        i++;
       }
      }
      
      System.out.println();
   }//end of method
  
  //Prints all double tokens
   public void printAllDoubleTokens(){
      int i = 1;//numeric lable
      String regex = "[0-9]+[0-9]+?\\.[0-9]+";//used to look for String pattern
      
      System.out.println("3.  All Double Tokens");
      System.out.println();
      
      //loops through arraylist
      for(int j = 0; j < list.size(); j++){
       String a = list.get(j);
       
       //checks if string contains double
       if(a.matches(regex)){
        
        //prints contents
        System.out.println(i + "\t" + list.get(j));
        
        //increment by one
        doubleTokens++;
        i++;
       }
      }//end of loop
     System.out.println();
   }//end of method
 
  //Prints all integer tokens
   public void printAllIntegerTokens(){
      int i = 1;//numeric lable
      String regex = "[\\d]+";//used to look for String pattern
      
      System.out.println("4.  Integer Tokens");
      System.out.println();
      
       //loops through arraylist
       for(int j = 0; j < list.size(); j++){
       String a = list.get(j);
       
       //checks if string contains integer
       if(a.matches(regex)){
        
        //prints contents
        System.out.println(i + "\t" + list.get(j));
        
        //increment by one
        integerTokens++;
        i++;
       }
      }//end of loop
     System.out.println();
   }//end of method

   public void printOtherTokens(){
      int i = 1;//numeric lable
      
      //used to look for String pattern
      String regex = "[\\W]";
      String regex2 = "[A-Z-a-z]+[\\W]+";
      String regex3 = "[A-Za-z]+[0-9]";
      String regex4 = "[\\d]+[\\W]([\\d]+[\\W][\\d]+)?";
      
      System.out.println("5.  Other Tokens");
      System.out.println();
      
      //loops through arraylist
      for(int j = 0; j < list.size(); j++){
       String a = list.get(j);
       
       //checks if string contains "'"
       if(a.contains("'")){
         System.out.println(i + "\t" + list.get(j));	
		   i++;
         otherTokens++;
        }
       //checks if string contains special charcter       
         else if(a.matches(regex)){
          System.out.println(i + "\t" + list.get(j));	
		    i++;
          otherTokens++;
       } 
       
       //checks if string contains letters and special characters
       else if(a.matches(regex2)){
          System.out.println(i + "\t" + list.get(j));	
		    i++;
          otherTokens++;
       }   
       
       //checks if string contains letters and numbers
       else if(a.matches(regex3)){
         System.out.println(i + "\t" + list.get(j));	
		    i++;
          otherTokens++;
       } 
       
       //checks if string contains letters and special characters
       else if(a.matches(regex4)){
         System.out.println(i + "\t" + list.get(j));	
		    i++;
          otherTokens++;
       }  
     }//end of loop
    System.out.println();
   }//end of method
   
  
 //Counts the number of each type of token
  public void countNumberOfTokens(Scanner scan){
    //Data fields
    String regex2 = "[\\d]+";
    int stringCount = list.get(0).length();
    
    //Count number of non-empty lines
    while(scan.hasNextLine()) {
       nonEmptyLines++;
       scan.nextLine();
      }
      scan.close();
        
     for(int j = 0; j < list.size(); j++){ 
       
       String a = list.get(j);
       
       //converts string to array of char
       char[] b = a.toCharArray();
       
       //Finding largest word
       if (list.get(j).length() > stringCount){
         stringCount = list.get(j).length();
         index = j ;
       }
       
       //Finding largest number
       if (a.matches(regex2)){
         if (Double.parseDouble(list.get(j)) > max)
           max = Double.parseDouble(list.get(j));
       }
       //Count digits, letters, chracters
       for(int i = 0; i < b.length; i++){
                
        if(Character.isDigit(b[i]))
         numOfDigits++;
      
        else if(Character.isLetter(b[i]))
         numOfLetters++;
      
        else
         numOfSpecialCharacters++;     
         numOfCharacters++;
      }
    }//end of loop
      
     
     
  }//end of method
   
   //Calculates total type of tokens
   public void totalTokens(){
     totalCountOfTokens = allTokens + alphabetTokens +
                          integerTokens + otherTokens;
   }
   
   //Prints infomation
   public void printCounts(){
     System.out.println("Count of non-empty lines tokens: " + nonEmptyLines);
     System.out.println("Count of all tokens: " +  allTokens);
     System.out.println("Count of alphabet tokens: " +   alphabetTokens);
     System.out.println("Count of integer tokens: " +  integerTokens);
     System.out.println("Count of Double tokens: " +  doubleTokens);
     System.out.println("Count of Other tokens: " +  otherTokens);
     System.out.println();
     System.out.println("Count of characters: " + numOfCharacters);
     System.out.println("Count of Digits: " + numOfDigits);
     System.out.println("Count of Letters: " + numOfLetters);
     System.out.println("Count of Other Characters: " + numOfSpecialCharacters);
     System.out.println();
     System.out.println("Longest alphabet token: " + list.get(index));
     System.out.println("Largest numeric value: " + max);
     System.out.println("Count of total tokens: " + totalCountOfTokens);
  }//end of method

}//end of class  
