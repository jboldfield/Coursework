//***************************************************************************************
//Purpose: Test the ProcessTokens6 class by sending the class a data file 				
//
//Author: Charles Samuel and Jonnie Oldfield
//Course: CS 1302
//Date:   2/16/2018
//Program: MyCounts6
//**************************************************************************************

import java.util.Scanner;
import java.io.*;

public class MyCounts6 {
  public static void main(String[] args)throws IOException {
    try{
    //creates two Scanner objects
    Scanner scan = new Scanner(new File(args[0])); 
    Scanner scan2 = new Scanner(new File(args[0]));   
    
    //create an object of ProcessTokens6
    ProcessTokens6 x = new ProcessTokens6();
   
    //invokes methods in ProcessTokens6
    x.addFiletoArrayList(scan);
    x.printAllTokens();
    x.printAllAlphabetTokens(); 
    x.printAllDoubleTokens();
    x.printAllIntegerTokens();
    x.printOtherTokens();
    x.countNumberOfTokens(scan2);
    x.totalTokens();
    x.printCounts();
   }
   
   catch(Exception e){
    System.out.print("No file is found at args[0]");
   }
 }//end of main
	
}//end of class
