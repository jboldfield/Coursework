//*****************************************************************************
//Purpose:  Basic Rectangle class. Modify as needed to work with Generics
//          and returns Rectangle information
//
//Author:   Charles Samuel and Johnnie Oldfield
//
//Course:   CS 1302
//
//Date:     3/5/2018
//
//*****************************************************************************

import java.text.DecimalFormat;

 //Class implements the Comparable interface
public class Rectangle8 extends MyGenerics8 implements Comparable<Rectangle8> {
  private double width = 1;
  private double height = 1;

  //No arg Constructor
  public Rectangle8() {
  }
  
  //Constructor that accepts a new witch and height
  public Rectangle8(double width, double height) {
    this.width = width;
    this.height = height;
  }

  /** Return width */
  public double getWidth() {
    return width;
  }

  /** Set a new width */
  public void setWidth(double width) {
    this.width = width;
  }

  /** Return height */
  public double getHeight() {
    return height;
  }

  /** Set a new height */
  public void setHeight(double height) {
    this.height = height;
  }

  /** Return area */
  public double getArea() {
    return width * height;
  }

  /** Return perimeter */
  public double getPerimeter() {
    return 2 * (width + height);
  }
  
     
  @Override
  //Compares the Perimeter of each rectangle
  public int compareTo(Rectangle8 object){
    return (int)(getPerimeter() - object.getPerimeter());
  }
  
  //Prints rectangle information
  public String display(){
   return String.format ("\n\n\tRectangle Information:\n\t%-15s%.2f\n\t%-15s%.2f\n\t%-15s%.2f\n\t%-15s%.2f",
		                   "Width:", width, "Height:", height,
		                   "Area:", getArea(), "Perimeter:", getPerimeter());                 
  }


}//end of class
