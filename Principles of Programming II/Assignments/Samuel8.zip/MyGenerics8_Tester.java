//*****************************************************************************
//Purpose:  Driver to invoke generics methods to sort and display 
//          different types  of arrays
//
//Author:   Charles Samuel and Johnnie Oldfield
//
//Course:   CS 1302
//
//Date:     3/5/2018
//
//*****************************************************************************
public class MyGenerics8_Tester{
   public static void main (String [] args){
      //1.  Declarations
      String [] stringList = {"Basem","Xavier", "Gregory", "Jenny","Cori", "Mitchel"};
      Double [] doubleList = {10.5, 2.7, 3.0, 15.25, 3.75, 9.11};
      Integer [] integerList = {4, 22, 7, 50, 8};
      Circle8 [] circleList = {new Circle8 (5), new Circle8 (20), new Circle8 (10)};
      Rectangle8 [] rectangleList = {new Rectangle8 (3, 4), new Rectangle8 (10, 2), new Rectangle8 (2, 3)};
      
      MyGenerics8 mf = new MyGenerics8();
      
      //2.  Display various lists
      System.out.println ("\n\n\tOriginal listing");
      mf.display (stringList);
      mf.display (doubleList);
      mf.display (integerList);
      mf.display (circleList);
      mf.display (rectangleList);
     
      
      //3.  Sort various lists. stringList, doubleList, and integerList by value
      //    circleList by area and rectangleList by perimeter
     mf.sortList (stringList);
     mf.sortList (doubleList);
     mf.sortList (integerList);
     mf.sortList (circleList);
     mf.sortList (rectangleList);

      //4.  Display various lists after sorting
      System.out.println ("\n\n\tAfter Sorting");
      mf.display (stringList);
      mf.display (doubleList);
      mf.display (integerList);
      mf.display (circleList);
      mf.display (rectangleList);
      
   }
}
      