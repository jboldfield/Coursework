//*****************************************************************************
//Purpose:  Basic Circle class. Modify as needed to work with Generics
//          and returns Circle information
//
//Author:   Charles Samuel and Johnnie Oldfield
//
//Course:   CS 1302
//
//Date:     3/5/2018
//
//*****************************************************************************

import java.text.DecimalFormat;

//Class implements the Comparable interface
public class Circle8 extends MyGenerics8 implements Comparable<Circle8> {
  private double radius = 0;

  ///No arg Constructor
  public Circle8() {
  }

  //Constructor that accepts a new radius
  public Circle8(double radius) {
    this.radius = radius;
  }

  /** Return radius */
  public double getRadius() {
    return radius;
  }

  /** Set a new radius */
  public void setRadius(double radius) {
    this.radius = radius;
  }

  /** Return area */
  public double getArea() {
    return radius * radius * Math.PI;
  }
  
  /** Return diameter */
  public double getDiameter() {
    return 2 * radius;
  }
  
  /** Return perimeter */
  public double getPerimeter() {
    return 2 * radius * Math.PI;
  }

    
  @Override
  ////Compares the Area of each Circle
  public int compareTo(Circle8 object){
    return (int)(getArea() - object.getArea());
  }

  //Prints rectangle information
  public String display(){
     return String.format ("\n\n\tCircle Information:\n\t%-15s%.2f\n\t%-15s%.2f\n\t%-15s%.2f",
		                     "Radius:", radius, "Area:", getArea(), "Perimeter:", getPerimeter());                 
  }

}
