//*****************************************************************************
//Purpose:   Sorts and displays different types of arrays using
//           Generic methods
// 
//Author:    Charles Samuel and Johnnie Oldfield
//
//Course:    CS 1302
//
//Date:      3/5/2018
//
//*****************************************************************************

public class MyGenerics8 {

 ///No arg Constructor
 public MyGenerics8(){
 
 }
 
 //Generic method sorts array
 public <E extends Comparable<E>> void sortList(E[] list){
  E min = null;
  int minIndex = 0;
  
  //loops through array and sorts in ascending order
  for(int i = 0; i < list.length; i++){
   min = list[i];
   minIndex = i;
    
    //compares each element in the array
    for(int j = i + 1; j < list.length; j++){
     if(min.compareTo(list[j]) > 0){
      min = list[j];
      minIndex = j;
     }
    }
    
    //swaps elements
    if(minIndex != i){
     list[minIndex] = list[i];
     list[i] = min;
    }
  
  }//end of loop 
  
 }//end of method
 
//Generic method displays elements in array
 public <E> void display(E[] list){
  
   for(int i = 0; i < list.length; i++){
    
    //checks if object in an instance of Circle8 and prints contents
    if(list[i] instanceof Circle8)
      System.out.println((i +1) + ".  " + ((Circle8)list[i]).display());
    
    //checks if object in an instance of Rectangle8 and prints contents
    else if(list[i] instanceof Rectangle8)
      System.out.println((i +1) + ".  " + ((Rectangle8)list[i]).display());

    else
      System.out.println((i + 1) + ".  " + list[i]);
    }
  
  System.out.println();  
 }//end of method
 
}//end of class