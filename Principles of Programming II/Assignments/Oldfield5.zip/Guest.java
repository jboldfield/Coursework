//Name:			Johnnie Oldfield
//Program Name:	Guest
//Date:			02/09/2018
//Purpose:		A parent class for the different
//				types of guests that visit the diner
//************************************************
public abstract class Guest{
	//Place order
	abstract public int[] getOrder();
}
