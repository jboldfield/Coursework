import java.io.*;
import java.util.Scanner;
import java.util.*;

public class MyCourse8_Tester {
   public static void main (String [] args)throws IOException{
   //input text file
		File infile1 = new File ("data8.txt"); //text lines
		Scanner scan = new Scanner (infile1);
      
      MyCourse8 mg = new MyCourse8(scan);

   
   }

}