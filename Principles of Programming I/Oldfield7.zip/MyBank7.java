public class MyBank7{
	public static void main (String[] args) {
	  ProcessMyAccount7 msp = new ProcessMyAccount7();
	}
}