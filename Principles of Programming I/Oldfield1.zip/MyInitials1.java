//***********************************************************
//	Purpose:	Getting started with Java and JGRASP. Creating, saving, 
//			compiling, debugging, and running a Java program.
//			
//	Input:		None
//	Output:		Displaying a short paragraph about yourself and 
//			your initials in large block letters. 
//	Author:		Johnnie Oldfield
//	Date:		   8/16/2017
//	Class:		CS1301A
//	Program:	#1 (MyInitials1.java)
//***********************************************************
public class MyInitials1{
   //*************************************
   //main method
   //*************************************
   public static void main (String[] args){
      System.out.println ("My name is Johnnie Oldfield and I am from Live Oak, Florida.  I chose VSU because out of the several universities I looked in to VSU was really the only one with a decent CS department.  My major is Computer Information Systems.  ");
      System.out.println ("JJJJJJJJJJJJ  BBBBBBBBB     OOOOOOOOO  ");
      System.out.println ("JJJJJJJJJJJJ  BBBBBBBBBBB  OOOOOOOOOOO ");
      System.out.println ("    JJJ       BBB     BBB OOO       OOO");
      System.out.println ("    JJJ       BBB    BBBB OOO       OOO");
      System.out.println ("    JJJ       BBBBBBBBBBB OOO       OOO");
      System.out.println ("    JJJ       BBBBBBBBBBB OOO       OOO");
      System.out.println ("    JJJ       BBB    BBBB OOO       OOO");
      System.out.println ("JJ  JJJ       BBB     BBB OOO       OOO");
      System.out.println ("JJJJJJJ       BBBBBBBBBBB  OOOOOOOOOOO ");
      System.out.println ("JJJJJJJ       BBBBBBBBB     OOOOOOOOO  "); 
      //Ininitials J.B.O  
   }//end of main
}//end of class  