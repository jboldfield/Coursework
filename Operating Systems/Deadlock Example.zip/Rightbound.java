// Thread for right-bound cars. Makes new thread with car object,
// thread sleeps for a random amount of time. Runs infintly.
public class Rightbound extends Thread{
    Tunnel tunnel;

    public Rightbound(Tunnel tunnel){
        this.tunnel = tunnel;
    }

    // Keeps right-bound cars odd
    int n = 1;

    public void run() {
        while(true){
            Car car = new Car(tunnel);
            Thread thread = new Thread(car);
            car.setCar("Right-Bound Car " + n);
            thread.start();
            n += 2;
            try{
                thread.sleep((long)(Math.random()*10000));
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
    }
}