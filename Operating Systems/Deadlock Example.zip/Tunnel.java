/* Tunnel object that cars 'cross'. Displays output for cars that are
 * waiting on the tunnel, in the tunnel, and exiting the tunnel.
 */

import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

class Tunnel{
    private Semaphore semaphore;

    public Tunnel(){
        semaphore = new Semaphore(1);
    }

    public void crossTunnel(Car car){
        try{
            System.out.printf("\t%s wants to enter the tunnel.\n", car.getCar());
            semaphore.acquire();
            System.out.printf("\t%s is in the tunnel.\n", car.getCar());
            TimeUnit.SECONDS.sleep((long)(Math.random() * 10));
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            System.out.printf("\t%s is exiting the tunnel.\n", car.getCar());
            semaphore.release();
        }
    }
}