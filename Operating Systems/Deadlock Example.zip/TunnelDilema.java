/* Authors: James Jackson & Johnnie Oldfield
 * Purpose: Java program that prevents deadlock using semaphore.
 *          Semaphore is being used in the Tunnel class.
 */

 // Creates threads and starts threads. 
public class TunnelDilema {
    public static void main(String[] args) {
        // How to stop program
        System.out.println("\n\t\t  **Ctrl+C to stop.**");
        
        // New tunnel object
        Tunnel tunnel = new Tunnel();
        
        // Create right bound and left bound threads 
        Rightbound rightbound = new Rightbound(tunnel);
        Leftbound leftbound = new Leftbound(tunnel);
        
        // Start threads
        rightbound.start();
        leftbound.start();
    }
 
}