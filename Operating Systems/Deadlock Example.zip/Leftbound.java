// Thread for left-bound cars. Makes new thread with car object,
// thread sleeps for a random amount of time. Runs infintly.
public class Leftbound extends Thread{
    Tunnel tunnel;

    public Leftbound(Tunnel tunnel){
        this.tunnel = tunnel;
    }

    // Keeps left-bound cars even
    int s = 2;

    public void run() {
        while(true){
            Car car = new Car(tunnel);
            Thread thread = new Thread(car);
            car.setCar("Left-Bound Car " + s);
            thread.start();
            s += 2;
            try{
                thread.sleep((long)(Math.random()*10000));
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
    }
}