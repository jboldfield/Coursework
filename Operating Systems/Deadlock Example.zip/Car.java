/* Car object that keeps track of car's number and
 *  makes the car cross the tunnel. 
 */

class Car implements Runnable{
    private String car;
    private Tunnel tunnel;
    
    public Car(Tunnel tunnel){
        this.tunnel = tunnel;
    }

    public String getCar() {
        return car;
    }
 
    public void setCar(String car) {
        this.car = car;
    }

    public void run(){
        tunnel.crossTunnel(this);
    }
}