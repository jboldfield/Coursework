/*  Johnnie Oldfield
 *  CS 4345 (Operating Systems)
 *  Spring 2019
 *  Assignment - 2
 */

import java.util.*;
import java.util.function.Predicate;
import java.io.*;

public class CPU_Scheduler  {
    //Process Object 
    public static class Process {
        //Data field
        int id = (int)(Math.random() * 11);
        int burst_length = (int)(Math.random() * 81 + 20);
        int priority = (int )(Math.random() * 10 + 1);
        String algorithm = "";
        int waiting_time = 0;

        //no-arg constructor
        public Process(){

        }

        //constructor
        public Process(int id, int burst_length, int priority) {
            this.id = id;
            this.burst_length = burst_length;
            this.priority = priority;
        }

        public Process(int id, int burst_length, int priority, String algorithm, int waiting_time) {
            this.id = id;
            this.burst_length = burst_length;
            this.priority = priority;
            this.algorithm = algorithm;
            this.waiting_time = waiting_time;
        }

        public int getId(){
            return this.id;
        }

        public int getPriority(){
            return this.priority;
        }

        public int getBurst(){
            return this.burst_length;
        }
    }

    public static void main (String[] args){
        ArrayList <Process> list = makeProcesses();
        snapshot(list);
        list = getInput(list);
        snapshot(list);
        results(list);
    }

    public static ArrayList<Process> makeProcesses(){
        ArrayList <Process> list = new ArrayList<>();
        while(list.size() < 5){
            Process process = new Process();
            if(inList(list, process.id) == false){
                list.add(process);
            }
        }
        return list;
    }

    public static void snapshot(ArrayList<Process> list){
        System.out.printf("%-18s|%-18s|%-18s\n", 
                          "   Process ID",
                          "      Priority",
                          "   Burst-length");
        for(Process process : list){
            System.out.printf("%12d%18d%18d\n", 
                          process.id,
                          process.priority,
                          process.burst_length);
        }
        System.out.println();
    }

    public static ArrayList<Process> getInput(ArrayList<Process> list){
        int id, priority, burst, choice = 1; 
        while(choice != 0){
            id = 11;
            priority = 0; 
            burst = 0;
            Scanner scan = new Scanner(System.in);
            System.out.println("Enter 1 to make process. 0 to skip.");
            choice = scan.nextInt();
            System.out.println();
            if(choice == 0){
                break;
            }
            while(id < 0 || id > 10){
                System.out.println("Enter Process ID(0-10): ");
                id = scan.nextInt();
                System.out.println();
                if(id < 0 || id > 10){
                    System.out.println("Pick a value between 0-10.");
                }
                if(inList(list, id)){
                    System.out.println("ID already exists.");
                    id = 11;
                }
            }
            while(priority < 1 || priority > 10){
                System.out.println("Enter Priority(1-10): ");
                priority = scan.nextInt();
                System.out.println();
                if(priority < 1 || priority > 10){
                    System.out.println("Pick a value between 1-10.\n");
                }
            }
            while(burst < 20 || burst > 100){
                System.out.println("Enter Burst-length(20-100): ");
                burst = scan.nextInt();
                System.out.println();
                if(burst < 20 || burst > 100){
                    System.out.println("Pick a value between 20-100.\n");
                }
            }
            list.add(new Process(id, burst, priority));
            System.out.println("Enter 1 to make another process. 0 to end.");
            choice = scan.nextInt();
            System.out.println();
            scan.close();
        }
        return list;
    }

    public static boolean inList(ArrayList<Process> list, int id){
        for(Process process : list){
            if(process.id == id){
                return true;
            }
        }
        return false;
    }

    public static void results(ArrayList<Process> list){
        int avg_sjf = 0;
        int avg_priority = 0;
        int avg_rr = 0;
        System.out.printf("%-18s|%-18s|%-18s|%-35s|%-25s\n", 
                          "     Process ID",
                          "      Priority",
                          "   Burst-length",
                          "      Schedulting algorithm",
                          "  Total waiting time");
        ArrayList<Process> sjf = compSJF(list);
        for(Process process : sjf){
            avg_sjf += process.waiting_time;
        }
        avg_sjf /= sjf.size();
        for(Process process : sjf){
            System.out.printf("%12d%18d%18d%40s%18d\n", 
                          process.id,
                          process.priority,
                          process.burst_length,
                          process.algorithm,
                          process.waiting_time);
        }
        ArrayList<Process> priority = compPriority(list);
        for(Process process : priority){
            avg_priority += process.waiting_time;
        }
        avg_priority /= priority.size();
        for(Process process : priority){
            System.out.printf("%12d%18d%18d%40s%18d\n", 
                          process.id,
                          process.priority,
                          process.burst_length,
                          process.algorithm,
                          process.waiting_time);
        }
        int bursts[] = new int[list.size()];
        int ids[] = new int[list.size()];
        int x = 0;
        for(Process process : list){
            bursts[x] = process.burst_length;
            ids[x] = process.id;
            x++;
        }
        ArrayList<Process> rr = runRR(list);
        for(Process process : rr){
            for(int i = 0; i < ids.length; i++){
                if(process.id == ids[i]){
                    process.burst_length = bursts[i];
                }
            }
            process.algorithm = "Round Robin";
            avg_rr += process.waiting_time;
        }
        avg_rr /= priority.size();
        for(Process process : rr){
            System.out.printf("%12d%18d%18d%40s%18d\n", 
                          process.id,
                          process.priority,
                          process.burst_length,
                          process.algorithm,
                          process.waiting_time);
        }
        System.out.println("\n\t\tAverage SJF: " + avg_sjf + ".\tAverage Priority: " 
                            + avg_priority + ".\t\tAverage Round Robin: " + avg_rr + ".");
    }

    public static ArrayList<Process> compSJF(ArrayList<Process> list){
        ArrayList<Process> sjf = list; 
        
        for(Process process : sjf){
            process.algorithm = "Non-preemptive SJF";
        }
        Collections.sort(sjf, (p1, p2) -> p1.getBurst() - (p2.getBurst()));
        sjf.get(0).waiting_time = 0;
        for(int i = 1; i < sjf.size(); i++){
            sjf.get(i).waiting_time = sjf.get(i - 1).burst_length + sjf.get(i-1).waiting_time;
        }
        return sjf;
    }

    public static ArrayList<Process> compPriority(ArrayList<Process> list){
        ArrayList<Process> priority = list; 
        
        for(Process process : priority){
            process.algorithm = "Non-preemptive Priority";
        }
        Collections.sort(priority, (p1, p2) -> p1.getPriority() - (p2.getPriority()));
        priority.get(0).waiting_time = 0;
        for(int i = 1; i < priority.size(); i++){
            priority.get(i).waiting_time = priority.get(i-1).burst_length + priority.get(i-1).waiting_time;
        }
        return priority;
    }

    public static ArrayList<Process> runRR(ArrayList<Process> list){
        ArrayList<Process> rr = new ArrayList<Process>();
        ArrayList<Process> temp = list;
        int q = 20;
        int time = 0;
        int runtime = 0;
        for(Process process : temp ){
            runtime += process.burst_length;
        }

        while(runtime > 0){
            for(Process process : temp){
                if(process.burst_length > 0){
                    time = process.burst_length;
                    if (time > q){
                        process.waiting_time = 20;
                        process.burst_length -= q;
                        time -= q;
                        runtime -= q;
                    }
                    else {
                        process.waiting_time = time;
                        runtime -= time;
                        process.burst_length  = 0;
                        time = 0;
                    }
                    rr.add(new Process(process.id, process.burst_length, process.priority, process.algorithm, process.waiting_time));
                }
                else {
                }
            }
        }
        rr.get(0).waiting_time = 0;
        for(int i = 1; i < rr.size(); i++){
            rr.get(i).waiting_time += rr.get(i-1).waiting_time;
        }
        int i = 0;
        rr.removeIf(process -> process.burst_length != 0);

        return rr;
    }
}