/*  Johnnie Oldfield
 *  CS 4345 (Operating Systems)
 *  Spring 2019
 *  Assignment - 2
 */

I started of by making a process object to hold all related data for a 
process.  Then running the makeProcesses() method will generate five
processes all with random assigned values and add them to an array 
list.  isList() is used to check if process ID already exists. The 
snapshot() will then print those processes. The getInput() is then ran 
to get user input for more processes and checks validity of input
values. snapshot() is then ran again to display new process(s).  
results() will then print all processes undergoing each algorithm.
The compSJF(), compPriority(), and runRR() are ran inside results() to
grab new lists that have went through the different algorithms. 
compSJF() and compPriority() have comparitors that sort the lists to 
make them easier to run the algorithm.   
